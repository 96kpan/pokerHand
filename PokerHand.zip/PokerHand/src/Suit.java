//Katie Pan
//Suit.java
//Enum for Suits

public enum Suit {
	Clubs,
	Diamonds,
	Hearts,
	Spades;
}
