//Katie Pan
//HandRank.java
//Enum for HandRanks

public enum HandRank {
	Nothing(1),
	Pair(2),
	Two_Pair(3),
	Three_of_a_Kind(4),
	Straight(5),
	Flush(6),
	Full_House(7),
	Four_of_a_Kind(8),
	Straight_Flush(9);
	
	final int handRank;
	
	//constructor that sets the rankOfHand per hand
	private HandRank(int rankOfHand){
		handRank = rankOfHand;
	}
	
	//getter for the HandRank
	public int getHandRank(){
		return handRank;
	}
}
