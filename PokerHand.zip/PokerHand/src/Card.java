//Katie Pan
//Card.java
//Card Object that stores the rank and suit for each card

public class Card implements Comparable<Card>{
	
	private final Rank cardRank;
	private final Suit cardSuit;

	//constructor that allows object Card to have a rank and a suit
	public Card(Rank rankOfCard, Suit suitOfCard){
		
		cardRank = rankOfCard;
		cardSuit = suitOfCard;
		//System.out.println("cardRank " + cardRank + " cardSuit " + cardSuit);
	}

	//getter method
	//gets the suit of the card
	public Suit getSuit() {
		//System.out.println("hererere cardRank " + cardRank + " cardSuit " + cardSuit);
		return cardSuit;
		
	}

	//getter method
	//gets the rank of the card
	public Rank getRank() {
		return cardRank;
	}

	//implements interface comparable
	@Override
	public int compareTo(Card card) {
		return this.getRank().getValue() - card.getRank().getValue();
	}
	
}