//Katie Pan
//DuplicateCardException.java
//Exception thrown when two of the same card is in either one person's hand or both person's hands



@SuppressWarnings("serial")
public class DuplicateCardException extends RuntimeException {
	
	public DuplicateCardException(){
		super("");
	}
}
