//Katie Pan
//PokerHand.java
//This class has the ability to compare PokerHand objects where one higher 
//ranked hand is greater than another lower ranking hand

import java.util.*;


public class PokerHand implements Comparable<PokerHand>{

	private Card[] myDeck = new Card[5];
	private int[] myDeckRank = new int[5];
	private HandRank handRank;
	HashMap<Integer, Integer> myDeckMap;

	
	//constructor that takes 5 cards EXACTLY
	public PokerHand(Card card1, Card card2, Card card3, Card card4, Card card5) {

		//sets them to the private variable
		myDeck[0] = card1;
		myDeck[1] = card2;
		myDeck[2] = card3;
		myDeck[3] = card4;
		myDeck[4] = card5;	

		//myDeckRank is unnecessary, but added for easy access to the ranks, instead of constantly
		//getting values
		myDeckRank[0] = card1.getRank().getValue();
		myDeckRank[1] = card2.getRank().getValue();
		myDeckRank[2] = card3.getRank().getValue();
		myDeckRank[3] = card4.getRank().getValue();
		myDeckRank[4] = card5.getRank().getValue();

		//checks if the hand has a duplicate card, if so, throw an exception
		if(duplicateCards(this)){
			throw new DuplicateCardException();
		}

		//fills hashmap that holds the RANK and the FREQUENCY of each rank
		fillMap(myDeck);
		//sorts the deckRank to be in order
		Arrays.sort(myDeckRank);

		//calculates rank for hand
		handRank = calculateRank(this);

	}

	//boolean method that checks if there are duplicate cards in deck
	private boolean duplicateCards(PokerHand deck){
		for(int i = 0; i < deck.myDeck.length; i++){
			for(int j = i+1; j < deck.myDeck.length; j++){
				if(deck.myDeck[i].getRank() == deck.myDeck[j].getRank() &&
						deck.myDeck[i].getSuit() == deck.myDeck[j].getSuit()){
					return true;
				}
			}
		}

		return false;
	}

	//fills the hashmap with RANK, FREQUENCY (of each rank)
	private void fillMap(Card[] myDeck) {

		myDeckMap = new HashMap<Integer, Integer>();

		for(int i = 0; i < myDeck.length; i++){
			//if already contains the rank, just +1 to the frequency
			if(myDeckMap.containsKey(myDeck[i].getRank().getValue())){

				myDeckMap.put(myDeck[i].getRank().getValue(), myDeckMap.get(myDeck[i].getRank().getValue()) + 1);
			}
			
			//else, add new Rank with 1 frequency
			else{
				myDeckMap.put(myDeck[i].getRank().getValue(), 1);
			}
		}
	}

	//get key from value
	//traverse map to find specific VALUE
	@SuppressWarnings("rawtypes")
	public Integer getKeyFromValue( Integer freq) {
		
		HashMap<Integer,Integer> hm = myDeckMap;
		for (Integer o : hm.keySet()) {
			if (hm.get(o).equals(freq)) {
				return o;
			}
		}
		return null;
	}

	//PokerHand implements COMPARABLE interface
	//returns + if this.deck > otherDeck and vice versa
	//if returns 0, then go into the tieBreaker method
	public int compareTo(PokerHand otherDeck) {
		
		//if same card in 2 hands, throw exception
		for(int i = 0; i < myDeck.length; i++){
			for(int j = 0; j < otherDeck.myDeck.length; j++){
				if(myDeck[i].getRank() == otherDeck.myDeck[j].getRank() &&
						myDeck[i].getSuit() == otherDeck.myDeck[j].getSuit()){
					throw new DuplicateCardException();
				}
			}
		}

		if(this.handRank == otherDeck.handRank){
			return tieBreaker(this, otherDeck);
		}

		//System.out.println(myRank.ordinal() - otherRank.ordinal());
		return handRank.ordinal() - otherDeck.handRank.ordinal();
	}

	//calculates if pokerRank is the same between two decks 
	//if the ranks are the same, goes into the switch statements into specific type of rank
	//most rank must be treated differently from others
	private int tieBreaker(PokerHand hand, PokerHand otherHand) {

		int handValue1 = 0, handValue2 = 0;

		switch (handRank){

		//sum of a larger straight/straight flush WILL/MUST be larger
		case Straight_Flush:
		case Straight:
			handValue1 = sum(hand);
			handValue2 = sum(otherHand);
			break;

		//we only need to compare the key that has a value of 4 because
		//this is only one deck of cards (max of 4, no way can the other player
		//have the other cards and still fulfill the ranks)
		case Four_of_a_Kind:
			handValue1 = hand.getKeyFromValue(4);
			handValue2 = otherHand.getKeyFromValue(4);
			break;
			
		//we only need to compare the key that has a value of 3 because
		//this is only one deck of cards (max of 4, no way can the other player
		//have the other cards and still fulfill the ranks)
		case Full_House:
		case Three_of_a_Kind:
			handValue1 = hand.getKeyFromValue(3);
			handValue2 = otherHand.getKeyFromValue(3);
			break;

		//we want the largest number, whoever has the largest number, WINS
		case Flush:
		case Nothing:
			for(int i = 4; i >= 0; i--){
				if(hand.myDeckRank[i] != otherHand.myDeckRank[i]){
					handValue1 = hand.myDeckRank[i];
					handValue2 = otherHand.myDeckRank[i];
					break;
				}
			}
			break;
		
		//we need to compare both pairs (since one might be the same, but the other is larger)
		//also we need to compare if both pairs are the same, then we need to look at the single
		//card
		case Two_Pair:
			int maxPair1 = hand.maxPair();
			int maxPair2 = otherHand.maxPair();
			
			int minPair1 = hand.minPair();
			int minPair2 = otherHand.minPair();
		
			if(maxPair1 == maxPair2){
				
				if(minPair1 == minPair2){
					handValue1 = hand.getKeyFromValue(1);
					handValue2 = otherHand.getKeyFromValue(1);
				}
				
				else{
					return minPair1 - minPair2;
				}
				
			}
			else{
				return maxPair1-maxPair2;
			}
			break;
		
		//just compare the pair value, if the same
		//then we look at the other cards until we find the larger of the two
		case Pair:
			handValue1 = hand.getKeyFromValue(2);
			handValue2 = otherHand.getKeyFromValue(2);
			
			if(handValue1 == handValue2){
				for(int i = 4; i >= 0; i--){
					if(hand.myDeckRank[i] != otherHand.myDeckRank[i]){
						handValue1 = hand.myDeckRank[i];
						handValue2 = otherHand.myDeckRank[i];
						break;
					}
				}
			}
			break;
		}

		return handValue1-handValue2;	
	}

	//helper method that finds the MAX pair for the two_pairs
	private int maxPair() {
		int pair1 = 0;
		int pair2 = 0;
		
		for (Integer o : myDeckMap.keySet()) {
			if (myDeckMap.get(o).equals(2)) {
				if(pair1 == 0)
					pair1 = o;
				else{
					pair2 = o;
				}
			}
		}
		
		int max = Math.max(pair1, pair2);
		
		return max;
	}
	
	//helper method that finds the MIN pair for the two_pairs
	private int minPair() {
		int pair1 = 0;
		int pair2 = 0;
		
		for (Integer o : myDeckMap.keySet()) {
			if (myDeckMap.get(o).equals(2)) {
				if(pair1 == 0)
					pair1 = o;
				else{
					pair2 = o;
				}
			}
		}
		
		int min = Math.min(pair1, pair2);
		
		return min;
	}

	//helper method that adds the hand together
	private int sum(PokerHand hand) {
		int sum = 0;
		for(int i = 0; i < hand.myDeckRank.length; i++){
			sum += hand.myDeckRank[i];
		}
		return sum;
	}

	//calculates rank of deck of cards
	private HandRank calculateRank(PokerHand pokerHand) {

		//straight flush:
		//Five consecutive cards of the same suit
		if(sameSuit(pokerHand) && straight(pokerHand)){
			return HandRank.Straight_Flush;
		}

		//Four of a Kind
		//Four cards of the same rank and one other card, such as 9-9-9-9-Q
		if(myDeckMap.containsValue(4))
			return HandRank.Four_of_a_Kind;


		//Full House
		//Three cards of the same rank plus a pair of cards of another rank, such as 5-5-5-K-K
		if(myDeckMap.containsValue(3) && myDeckMap.containsValue(2)){
			return HandRank.Full_House;
		}


		//Flush
		//A flush consists of five cards of the same suit (not all consecutive, otherwise it would be a straight flush).
		if(sameSuit(pokerHand))
			return HandRank.Flush;

		//Straight
		//Five cards of consecutive ranks, not all of the same suit
		if(straight(pokerHand))
			return HandRank.Straight;

		//Three of a Kind
		//Three cards of the same rank and two cards of different ranks - for example 7-7-7-10-6
		if(this.myDeckMap.containsValue(3))
			return HandRank.Three_of_a_Kind;

		//Two Pair
		//Two cards of one rank, two cards of a second rank and one card of a third rank (the kicker) - for example J-J-3-3-8.
		if(this.myDeckMap.containsValue(2)){
			int pairCount = 0;
			for (Integer key : myDeckMap.keySet()) {
				if(myDeckMap.get(key) != null && myDeckMap.get(key) == 2){
					pairCount++;
				}
			}

			if(pairCount == 2){
				return HandRank.Two_Pair;
			}

			return HandRank.Pair;
		}


		else{
			return HandRank.Nothing;
		}

	}

	//tells if the deck has a straight
	private boolean straight(PokerHand pokerHand) {
		
		Arrays.sort(pokerHand.myDeckRank);

		for(int i = 0; i < pokerHand.myDeckRank.length-1; i++){
			if(pokerHand.myDeckRank[i]+1 != pokerHand.myDeckRank[i+1]){
				return false;
			}
		}

		return true;

	}

	//tells if the deck is the same suit
	private boolean sameSuit(PokerHand pokerHand) {

		for(int i = 0; i < pokerHand.myDeck.length-1; i++){

			if(!pokerHand.myDeck[i].getSuit().equals(pokerHand.myDeck[i+1].getSuit())){

				return false;
			}
		}

		return true;
	}

}
