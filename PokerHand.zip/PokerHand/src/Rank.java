//Katie Pan
//Rank.java
//Enum for Ranks

public enum Rank {
	Deuce(2),
	Three(3),
	Four(4),
	Five(5),
	Six(6),
	Seven(7),
	Eight(8),
	Nine(9),
	Ten(10),
	Jack(11),
	Queen(12),
	King(13),
	Ace(14);


	private int rankOfCard;

	//constructor
	//allows the enums to possess a int Rank
	private Rank(int rankOfCard){
		this.rankOfCard = rankOfCard;
	}
	
	//gets the Rank of Card. For example, Rank.Deuce returns a 2 and so on
	int getValue(){
		return this.rankOfCard;
	}
}